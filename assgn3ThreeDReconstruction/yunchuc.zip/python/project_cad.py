import numpy as np

# write your implementation here
